This is a Spring Integration sample to demonstrate how Spring Integration creates a facade over some complex integration scenarios - 

More Details [here](http://biju-allandsundry.blogspot.com/2014/05/spring-integration-java-dsl-sample.html) and [here](http://biju-allandsundry.blogspot.com/2014/06/spring-integration-java-dsl-sample.html)

The sample has now been updated to use Spring Integration Java based DSL.

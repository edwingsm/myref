package lankydan.tutorial.springboot.service;

import lankydan.tutorial.springboot.dto.PersonDTO;

public interface PersonService {

	boolean isValid(PersonDTO personDTO);

}

create table emails
(
   id integer not null auto_increment,
   to varchar(255) not null,
   body varchar(255) not null,
   primary key(id)
);
package com.example.spring.integration.springintegrationdemo;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.messaging.MessageHandler;


@Configuration
public class MongoIntegrationFlow {

	@Autowired
	MongoDbFactory mongo;
	
	@Autowired
	MessageHandler mongoOutboundAdapter;
	
	@Autowired
	PublishSubscribeChannel publishSubscribeChannel1;

	
	@Bean
	public IntegrationFlow mongoFlow() {
		return IntegrationFlows.from(publishSubscribeChannel1).handle(mongoOutboundAdapter).get();
	}
	
}

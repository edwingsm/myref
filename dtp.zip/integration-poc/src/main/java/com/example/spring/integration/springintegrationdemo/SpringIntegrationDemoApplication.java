package com.example.spring.integration.springintegrationdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.messaging.support.GenericMessage;

@SpringBootApplication
@EnableIntegration
@EnableJms
@EnableMongoRepositories
public class SpringIntegrationDemoApplication implements CommandLineRunner {

	@Autowired
	private DirectChannel jmsOutChannel1;

	public static void main(String[] args) {
		SpringApplication.run(SpringIntegrationDemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		jmsOutChannel1.send(new GenericMessage<Email>(new Email("from@gmail.com", "to@Gmail.com")));

	}

	
}

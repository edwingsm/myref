package com.example.spring.integration.springintegrationdemo;

import javax.jms.ConnectionFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.expression.common.LiteralExpression;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.jdbc.JdbcMessageHandler;
import org.springframework.integration.mongodb.inbound.MongoDbMessageSource;
import org.springframework.integration.mongodb.outbound.MongoDbStoringMessageHandler;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.messaging.MessageHandler;
import org.springframework.scheduling.support.PeriodicTrigger;



@Configuration
public class BeanConfigs {
	@Bean
	public JmsListenerContainerFactory<?> connectionFactory(ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		// This provides all boot's default to this factory, including the message
		// converter
		configurer.configure(factory, connectionFactory);
		// You could still override some of Boot's default if necessary.
		return factory;
	}

	@Bean // Serialize message content to json using TextMessage
	public MessageConverter jacksonJmsMessageConverter() {
		MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
		converter.setTargetType(MessageType.TEXT);
		converter.setTypeIdPropertyName("_type");
		return converter;
	}

	@Bean
	public QueueChannel jmsOutChannel() {
		return new QueueChannel();
	}

	@Bean
	public DirectChannel jmsOutChannel1() {
		return new DirectChannel();
	}

	@Bean
	public PublishSubscribeChannel publishSubscribeChannel1() {
		return new PublishSubscribeChannel();
	}
	

	@Bean(name = PollerMetadata.DEFAULT_POLLER)
	public PollerMetadata defaultPoller() {
		PollerMetadata pollerMetadata = new PollerMetadata();
		pollerMetadata.setTrigger(new PeriodicTrigger(10));
		return pollerMetadata;
	}

	@Bean
	public MessageHandler mongoOutboundAdapter(MongoDbFactory mongo) {
		MongoDbStoringMessageHandler mongoHandler = new MongoDbStoringMessageHandler(mongo);
		mongoHandler.setCollectionNameExpression(new LiteralExpression("emails"));
		return mongoHandler;
	}
	
	 @Bean
	    
	    public MessageSource<Object> mongoMessageSource(MongoDbFactory mongo) {
	        MongoDbMessageSource messageSource = new MongoDbMessageSource(mongo, new LiteralExpression("{'from' : }"));
	        //messageSource.setExpectSingleResult(true);
	        messageSource.setEntityClass(Email.class);
	        messageSource.setCollectionNameExpression(new LiteralExpression("emails"));

	        return messageSource;
	    }
	 @Bean
	    public MessageHandler jdbcMessageHandler(DataSource dataSource) {
	    	JdbcMessageHandler handler = new JdbcMessageHandler(dataSource,
	           "insert into emails (to, body) values ( :payload[to],:payload[body])");
	    	return handler;

	    }
}

package com.example.spring.integration.springintegrationdemo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.messaging.MessageHandler;


@Configuration
public class JdbcIntegrationFlow {

	@Autowired
	DataSource dataSource;
	
	@Autowired
	MessageHandler jdbcMessageHandler;
	
	@Autowired
	PublishSubscribeChannel publishSubscribeChannel1;

	
	@Bean
	public IntegrationFlow jdbcFlow() {
		return IntegrationFlows.from(publishSubscribeChannel1)
				.log(m -> m.getPayload().toString())
				//.handle(jdbcMessageHandler)
				.get();
	}
	
}

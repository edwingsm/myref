package com.example.spring.integration.springintegrationdemo;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.http.dsl.Http;
import org.springframework.integration.jms.dsl.Jms;

@Configuration
public class MainOrchestrationFlow {

	@Autowired
	private ConnectionFactory connectionFactory;

	@Autowired
	PublishSubscribeChannel publishSubscribeChannel1;
	


	@Bean
	public IntegrationFlow orchestrationFlow() {
		return IntegrationFlows
				.from(Jms.messageDrivenChannelAdapter(connectionFactory).destination("MAILBOX"))
				.channel(publishSubscribeChannel1)
				//.bridge()
				.<Email, String>transform(s -> {
					return s.toString().toLowerCase();
				}).log()
				.headerFilter("*", true)
				.log()
				// HTTP part goes here
				.<String, HttpEntity<String>>transform(HttpEntity::new).handle(
						Http.outboundGateway("http://localhost:8080/uppsercase").httpMethod(HttpMethod.POST)
								.extractPayload(true).expectedResponseType(String.class))
				.log()
				.headerFilter("*", true)
				.log()
				// and here HTTP part ends
				.handle(Jms.outboundAdapter(connectionFactory)
						.destination("MAILBOXX"))
				.get();
	}

}

(function(){
    return payload.length > 5 ? "longStrings" : "shortStrings";
})();

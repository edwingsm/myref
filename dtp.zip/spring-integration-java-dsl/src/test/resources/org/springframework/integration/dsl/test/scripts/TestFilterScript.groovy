headers.type == 'good'

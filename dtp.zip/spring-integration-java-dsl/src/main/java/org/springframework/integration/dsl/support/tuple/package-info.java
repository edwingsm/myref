/**
 * Tuples provide a type-safe way to specify multiple parameters.
 */
package org.springframework.integration.dsl.support.tuple;

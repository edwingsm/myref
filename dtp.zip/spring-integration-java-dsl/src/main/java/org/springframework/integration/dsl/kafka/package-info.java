/**
 * Provides Kafka Components support for Spring Integration Java DSL.
 */
package org.springframework.integration.dsl.kafka;

/**
 * Provides classes supporting Transactions.
 */
package org.springframework.integration.dsl.transaction;

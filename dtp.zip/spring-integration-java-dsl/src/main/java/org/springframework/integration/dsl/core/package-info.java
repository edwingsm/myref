/**
 * Provides core classes of the Spring Integration Java DSL.
 */
package org.springframework.integration.dsl.core;

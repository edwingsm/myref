/**
 * Provides config classes of the Spring Integration Java DSL.
 */
package org.springframework.integration.dsl.config;

/**
 * Provides JPA Components support for Spring Integration Java DSL.
 */
package org.springframework.integration.dsl.jpa;
